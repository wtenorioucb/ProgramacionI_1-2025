// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 2
// Problema planteado: Simular el lanzamiento de un dado n veces y determinar la frecuencia de repetición de las caras pares.
#include <stdlib.h>
#include <time.h>
#include <iostream>
using namespace std;
int lanzamiento_dados(int n, int inicio, int fin);
float frecuencia (int contador, int n);

int main()
{
    int inicio,fin,n,pares;
    double frecuencias;
    inicio=1;
    fin=6;
    cout << "ingrese el numero de veces que lanzamos el dado: ";
    cin >> n;
    pares= lanzamiento_dados (n,inicio,fin);
    frecuencias= frecuencia (pares,n);
    cout << "El % de las caras pares sera de: " << frecuencias;



}

int lanzamiento_dados(int n, int inicio, int fin)
{
    int random;
    int contador;
    contador=0;
    srand(time(NULL));
    cout << "Las caras de los dados sera: ";
    for(int i = 1; i <= n; i++)
    {
        random = inicio + rand() % ((fin + 1) - inicio);
        cout << random << " " ;
        if (random % 2 == 0)
        {
        contador+=1;
        }

    }
    cout << endl;
    return contador;
}

float frecuencia (int contador, int n)
{   
    float  resultado;
    resultado = static_cast<float> (contador)/n;
    return resultado;

}