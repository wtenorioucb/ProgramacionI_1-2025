// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 9
// Problema planteado: Generar (para un orden n): Sea n=5:
//1 0 1 0 1
//0 1 0 1 0
//1 0 1 0 1
//0 1 0 1 0
//1 0 1 0 1

#include <iostream>

using namespace std;

void imprimirLinea(int fila, int n);
void generarPatron(int n);

int main() 
{
    int n;

    cout << "Ingrese el valor de n: ";
    cin >> n;

    generarPatron(n);

    return 0;
}

void imprimirLinea(int fila, int n) 
{
    for (int j = 0; j < n; ++j) 
    {
        if ((fila + j) % 2 == 0)
        {
            cout << "1 ";
        } 
        else 
        {
            cout << "0 ";
        }
    }
    cout << endl;
}

void generarPatron(int n) 
{
    for (int i = 0; i < n; ++i) 
    {
        imprimirLinea(i, n);
    }
}
