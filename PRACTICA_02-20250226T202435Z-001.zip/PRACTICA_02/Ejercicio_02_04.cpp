// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 4
// Problema planteado:  Simular el lanzamiento de una moneda n veces y determinar el porcentaje de caras y el porcentaje de sellos.
#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;
void lanzamiento_moneda (int n, int cara, int cruz);
int main()
{
    int n, cara, cruz;
    cara = 1;
    cruz = 2;
    cout << "ingrese el numero de veces que la moneda dara vuelta: ";
    cin >> n;
    lanzamiento_moneda (n,cara,cruz);
    return 0;
}

void lanzamiento_moneda (int n, int cara, int cruz)
{
    int caras, contador_caras, contador_cruz;
    float resultado_caras, resultado_cruz;
    caras=0;
    contador_caras= 0;
    contador_cruz= 0;
    resultado_caras= 0;
    resultado_cruz= 0;
    srand(time(NULL));
    cout << "RECORDARTE QUE LOS *1* SON CARAS Y LOS *2* SON CRUCES" << endl ;
    cout << "Las caras de la moneda seran : " << endl ;
   
    for(int i = 1; i <= n; i++)
    {
        caras = cara + rand() % ((cruz + 1) - cara);
        cout << caras << " " ;
        if (caras == 1)
        {
        contador_caras += 1;
        }
        else
        {
        contador_cruz += 1; 
        }
        
    }
    cout << endl;
    resultado_caras = static_cast<float> (contador_caras) / n;
    resultado_cruz = static_cast<float> (contador_cruz) / n;
    cout << "el resultado del porcentaje de las veces que salio cara sera del: " << resultado_caras  << " %" << endl << "y de cruces sera: " << resultado_cruz << " %";

}    