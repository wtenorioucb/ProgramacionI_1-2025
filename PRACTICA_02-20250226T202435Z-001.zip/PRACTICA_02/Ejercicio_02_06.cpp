// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 6
// Problema planteado: Escribir un algoritmo que permita adivinar un número que se genere internamenteal azar, el cual está en el rango de 0 a 50. El usuario debe adivinar este número en base a aproximaciones para lo cual se dispone de 5 intentos.

#include <iostream>
#include <time.h>
#include <stdlib.h>
using namespace std;
int generar_aleatorio(int max, int min);

void realizar_intentos (int numeroPensado);

int main()
{
    int aleatorio;
    int min = 0;
    int max = 50;
    aleatorio = generar_aleatorio(max,min);
    cout << "El numero a adivinar sera... " << aleatorio << endl ;
    cout << "el numero a adivinar esta entre 0 y 50..." << endl ;
    realizar_intentos(aleatorio);

    return 0;
}

int generar_aleatorio(int max, int min)
{
    int aleatorio;
    aleatorio = min + rand() % ((max + 1) - min);
    return aleatorio; 

}

void realizar_intentos (int numeroPensado)
{
    int intento;
    int menor = 0;
    int mayor = 50;
    int intentos = 5;
    bool adivinado = false;
    
    for (int i = 1; i <= intentos; ++i) 
    {
        cout << "Intento " << i << endl;
        cin >> intento;
        
        if (intento == numeroPensado) 
        {
            cout << "Adivinaste el numero" << endl;
            adivinado = true;
            break;
        } 
        else if (intento < numeroPensado) 
        {
            cout << "El numero esta entre " << intento << " y " << mayor << endl;
            menor = intento;
        } 
        else 
        {
            cout << "El numero esta entre " << menor << " y " << intento << endl;
            mayor = intento;
        }
        if (intento > 5)
        {
        cout << "no pudiste adivinar el numero :(";
        }
    }
    
}