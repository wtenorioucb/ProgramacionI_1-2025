// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 3
// Problema planteado: Convertir un número en base n a base 10, empleando el Teorema Fundamental de la Numeración
#include <iostream>
#include <string>
#include <cmath>  

using namespace std;
int digitoEntero(char digito);

int convertirBase10(const string& numero, int base); 

int main() 
{
    string numero;
    int base;

    cout << "Ingrese el número en base n: ";
    cin >> numero;
    cout << "Ingrese la base del número : ";
    cin >> base;

        int resultado = convertirBase10(numero, base);
        cout << "El número " << numero << " en base " << base << " es " << resultado << endl;
   
    return 0;
}

int digitoEntero(char digito) 
{
    if (digito >= '0' && digito <= '9') 
    {
        return digito - '0'; 
    } 
    else if (digito >= 'A' && digito <= 'F') 
    {
        return digito - 'A' + 10;  
    }
    return 0;
}

int convertirBase10(const string& numero, int base) 

{
    int resultado = 0;
    int potencia = 0;

    for (int i = numero.size() - 1; i >= 0; --i) {
        char digito = numero[i];
        int valorDigito = digitoEntero(digito);
        resultado += valorDigito * pow(base, potencia);
        ++potencia;
    }

    return resultado;
}