// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 1
// Problema planteado: Obtener la suma de la serie: 4 + 6 + 9 + 13 + 19 + 28 + 42 +……. Para n términos

#include <iostream>
using namespace std;

int sumarSerie(int n) 
{
   if (n <= 0) 
    {
        return 0;
    }

    int termino1 = 4;
    int termino2 = 6;
    int suma = termino1; 

    if (n > 1) 
    {
        suma += termino2; 
    }

    
    int incremento = 1; 
    for (int i = 2; i < n; ++i) 
    {
        int siguienteTermino = termino1 + termino2 - incremento;
        suma += siguienteTermino;
        termino1 = termino2;
        termino2 = siguienteTermino;
        incremento++; 
    }

    return suma;
}


int main() 
{
    int n;
    
    cout << "Ingrese el número de términos : ";
    cin >> n;

    if (n <= 0) 
    {
        cout << "El número de términos debe ser positivo." << endl;
        return 1;
    }

    int suma = sumarSerie(n);
    cout << "La suma es " << suma << endl;

    return 0;
}
