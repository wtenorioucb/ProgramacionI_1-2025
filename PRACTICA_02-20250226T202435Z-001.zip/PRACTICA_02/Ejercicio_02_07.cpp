// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 7
// Problema planteado: Generar las secuencias:
//1 2 3 4 …………..n
//1 2 3 4……. n-1
//1 2 3 …...n-2
//……….
//1

#include <iostream>

using namespace std;

void imprimirSecuencia(int limite) {
    for (int i = 1; i <= limite; ++i) {
        cout << i << " ";
    }
    cout << endl;
}

void generarSecuencias(int n) 
{
    for (int i = n; i >= 1; --i) 
    {
        imprimirSecuencia(i);
    }
}

int main() 
{
    int n;

    cout << "Ingrese el valor de n: ";
    cin >> n;

    generarSecuencias(n);

    return 0;
}
