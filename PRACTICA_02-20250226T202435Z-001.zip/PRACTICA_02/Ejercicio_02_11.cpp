// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 10
// Problema planteado: calcular la cantidad de pañales que usan los niños de 1,2 y 3 años
#include <iostream>
#include <time.h>
#include <stdlib.h>
using namespace std;

void calcular_panales (int n, int inicio,int final);

int main()
{
    int n,inicio,final,bebes,resultado;
    resultado=0;
    inicio=1;
    final=3;
    bebes=0;
    cout << "ingrese el numero de bebes:  ";
    cin >> n;
    calcular_panales(n,inicio,final);

    return 0;
}

void calcular_panales(int n, int inicio,int final)
{
    int generador;
    int contador_uno = 0, contador_dos = 0, contador_tres = 0;
    srand(time(NULL));
    cout << "el numero de bebes ingresados sera: ";
    for (int i = 1; i <=n; i++)
    {
        generador= inicio + rand() % ((final + 1) - inicio);
        cout << generador << " " ;
        if (generador == 1)
        {
            contador_uno+=1;
        }
        else if (generador % 2 == 0)
        {
            contador_dos+=1;
        }
        else 
        {
            contador_tres+=1;
        }


    }

    cout << endl;
    cout << "los bebes de un año son:  " << contador_uno << endl;
    cout << "los bebes de dos años son:  " << contador_dos << endl ;
    cout << "los bebes de tres años son:  " << contador_tres;
    cout << endl;

    int calculo_uno = 0;
    int calculo_dos = 0;
    int calculo_tres = 0;

    calculo_uno = contador_uno * 6;
    calculo_dos = contador_dos * 3;
    calculo_tres = contador_tres * 2;

    cout << "el calculo de pañales de un año sera: " << calculo_uno << endl;
    cout << "el calculo de pañales de dos años sera: " << calculo_dos << endl;
    cout << "el calculo de pañales de tres años sera: " << calculo_tres;
}


    