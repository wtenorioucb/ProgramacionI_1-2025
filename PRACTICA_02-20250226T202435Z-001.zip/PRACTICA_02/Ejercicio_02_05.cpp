// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 5
// Problema planteado:  Genera un número aleatorio entre 1 y 10 y calcula su factorial
#include <iostream>
using namespace std;
 
int calcular_termino (int i);
int serie(int n);


int main()
{
    int n;
    int resultado = 0;
    cout << "ingrese un numero n: ";
    cin >> n;
    resultado = serie(n);
    cout << "el resultado para los numeros ingresados sera: " << resultado;

  
    return 0;
}

int calcular_termino (int i)
{
    int verificacion;
    verificacion=i*i;
    return verificacion;
}

int serie(int n)
{
 int suma = 0;
 for (int i = 1; i <= n; ++i) 
    {
        int termino = calcular_termino(i);

        if (i % 2 == 0) 
        {
            suma -= termino;
        }
        else 
        {
            suma += termino;
        }
    }

    return suma;

}