// Materia: Programación I, Paralelo 3
// Autor: Kevin Alejandro Guisbert Castillo
// Fecha creación: 25/02/2025
// Número de ejercicio: 8
// Problema planteado: Generar:
//121
//12321
//1234321
//123454321
//12345654321
//1234567654321
//123456787654321
//12345678987654321

#include <iostream>

using namespace std;

void imprimirLinea(int n); 

void generarPatron(int n);

int main() 
{
    int n;

    cout << "Ingrese el valor de n (máximo 9): ";
    cin >> n;

    generarPatron(n);

    return 0;
}

void imprimirLinea(int n) 
{
    for (int i = 1; i <= n; ++i) 
    {
        cout << i;
    }

    for (int i = n - 1; i >= 1; --i) 
    {
        cout << i;
    }
    
    cout << endl;
}

void generarPatron(int n) 
{
    for (int i = 1; i <= n; ++i) 
    {
        imprimirLinea(i);
    }
}